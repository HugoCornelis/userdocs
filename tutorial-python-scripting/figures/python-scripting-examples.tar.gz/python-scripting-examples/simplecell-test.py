#! /usr/bin/env python
"""
    simplecell-test.py - test of the simplecell model

    Basic Python script to load a cell model NDF file, provide current
    injection to the soma, and run the simulation, writing the soma Vm to
    a specified file.
"""
import pdb   # the Python debugger
import os
import sys

# This sets an environment to find the libraries needed for running SSPy
# It will likely not be required in later versions of G-3

sys.path.append( os.path.join(os.environ['HOME'],
    'neurospaces_project/sspy/source/snapshots/0/tests/python'))

# The location of model files to be loaded
os.environ['NEUROSPACES_NMC_MODELS']= '/usr/local/neurospaces/models/library'

# The following four commands set up SSPy as the scheduler component

from test_library import add_sspy_path
add_sspy_path()
from sspy import SSPy 
scheduler = SSPy(verbose=True)


# Create a model container service and load an ndf file
my_model_container = scheduler.CreateService(name="My Model Container",
    type="model_container", verbose=True)

# The commands above are common to most G-3 Python simulation scripts

# load a particular NDF cell model file
my_model_container.Load('cells/simplecell-nolib.ndf')

# set a model parameter, the INJECT field to provide constant current injection
my_model_container.SetParameter('/cell/soma', 'INJECT', 0.3e-09)

# Create a solver, in this case heccer
my_heccer = scheduler.CreateSolver('My solver', 'heccer', verbose=True)

# Sets the element of the model to run from
my_heccer.SetModelName('/cell')

# set the timestep for the entire scheduler (solvers, inputs and outputs)
my_heccer.SetTimeStep(2e-05)


#
# Create Outputs
#
my_output = scheduler.CreateOutput('My output object', 'double_2_ascii')

my_output.SetFilename('simplecell_soma_Vm.txt')

# this adds to output to the output object
my_output.AddOutput('/cell/soma', 'Vm')

# an alternate way is to add output to the top level SPPy object
# This is useful when interfacing with a GUI
# scheduler.AddOutput('/cell/soma', 'Vm')

# to apply this to a particular output object, one would use
# scheduler.AddOutput('/cell/soma', 'Vm', 'output1')

# Optionally, provide output a multiple of the simulation time step
my_output.SetResolution(5)

# finally run the simulation for a specified time or number of steps
scheduler.Run(time=0.5)
# scheduler.Run(steps=25000)

print "Done!"
